/**
 * DnD — Centralized instrument/symbol catalog.
 *
 * A static, curated registry of the trading instruments DnD knows about
 * out-of-the-box (forex majors/minors, metals, indices, futures, crypto).
 * Each entry carries the full metadata needed to drive:
 *
 *   - Price display precision (pricePrecision — number of decimals)
 *   - Pip/tick math for risk & P&L (pipSize, tickSize, contractSize,
 *     pointValueCents)
 *   - Market/category grouping in the InstrumentSelector UI
 *   - Unit labels ("pips" for forex, "points" for indices, "ticks" for
 *     futures — see `unitLabel` below)
 *
 * The catalog is intentionally a static module (no DB roundtrip) so that the
 * trade form, command palette, and any client surface can resolve an
 * instrument's spec synchronously. The Prisma `Instrument` model remains the
 * authoritative per-user store (a user may override these defaults or add
 * custom symbols); this catalog is the *fallback* used when no DB record
 * exists for a given symbol.
 *
 * Convention for `pointValueCents` (matches `computePointValueCents` in
 * `src/lib/calculations.ts`):
 *
 *   pointValueCents = max(100, round(contractSize × tickSize × 100))
 *
 * i.e. the dollar value (in cents) of a single tick move per 1.0 quantity.
 * Examples:
 *   - EURUSD: 100000 × 0.00001 × 100 = 100 cents  ($1 per tick per lot;
 *     1 pip = 10 ticks = $10 per lot)
 *   - XAUUSD: 100 × 0.01 × 100      = 100 cents  ($1 per 0.01 move per oz)
 *   - NQ:     20 × 0.25 × 100       = 500 cents  ($5 per tick per contract)
 *   - ES:     50 × 0.25 × 100       = 1250 cents ($12.50 per tick per
 *     contract)
 *   - BTCUSD: 1 × 0.01 × 100        = 1 cent → clamped to 100 (1:1 with
 *     price, $0.01 per tick per 1 BTC)
 */

export type InstrumentMarket =
  | "forex"
  | "gold"
  | "indices"
  | "futures"
  | "crypto"
  | "stocks"
  | "custom";

export interface InstrumentDef {
  /** Ticker symbol, uppercase, no whitespace. e.g. "EURUSD". */
  symbol: string;
  /** Human-readable name, e.g. "Euro / US Dollar". */
  displayName: string;
  /** Asset class. */
  market: InstrumentMarket;
  /** Sub-grouping within the market, e.g. "Major Pairs", "Metals". */
  category: string;
  /** Decimal places to use when displaying prices for this instrument. */
  pricePrecision: number;
  /** Decimal string. Size of 1 pip. "0.0001" for forex, "0.01" for gold. */
  pipSize: string;
  /** Decimal string. Minimum price increment (smallest tick). */
  tickSize: string;
  /** Decimal string. Notional units per 1.0 lot/contract.
   *  "100000" for a forex standard lot, "100" for gold (100 oz),
   *  "20" for NQ futures ($20 per point). */
  contractSize: string;
  /** Value (in cents) of a single tick move per 1.0 quantity.
   *  See convention note above. */
  pointValueCents: number;
}

/* ------------------------------------------------------------------ */
/* Catalog                                                             */
/* ------------------------------------------------------------------ */

export const INSTRUMENT_CATALOG: InstrumentDef[] = [
  /* ── FOREX Majors ─────────────────────────────────────────────── */
  {
    symbol: "EURUSD",
    displayName: "Euro / US Dollar",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "GBPUSD",
    displayName: "British Pound / US Dollar",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "USDJPY",
    displayName: "US Dollar / Japanese Yen",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 3,
    pipSize: "0.01",
    tickSize: "0.001",
    contractSize: "100000",
    pointValueCents: 10000,
  },
  {
    symbol: "USDCHF",
    displayName: "US Dollar / Swiss Franc",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "AUDUSD",
    displayName: "Australian Dollar / US Dollar",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "USDCAD",
    displayName: "US Dollar / Canadian Dollar",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "NZDUSD",
    displayName: "New Zealand Dollar / US Dollar",
    market: "forex",
    category: "Major Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },

  /* ── FOREX Minors / Crosses ───────────────────────────────────── */
  {
    symbol: "EURGBP",
    displayName: "Euro / British Pound",
    market: "forex",
    category: "Minor Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "EURJPY",
    displayName: "Euro / Japanese Yen",
    market: "forex",
    category: "Minor Pairs",
    pricePrecision: 3,
    pipSize: "0.01",
    tickSize: "0.001",
    contractSize: "100000",
    pointValueCents: 10000,
  },
  {
    symbol: "GBPJPY",
    displayName: "British Pound / Japanese Yen",
    market: "forex",
    category: "Minor Pairs",
    pricePrecision: 3,
    pipSize: "0.01",
    tickSize: "0.001",
    contractSize: "100000",
    pointValueCents: 10000,
  },
  {
    symbol: "AUDJPY",
    displayName: "Australian Dollar / Japanese Yen",
    market: "forex",
    category: "Minor Pairs",
    pricePrecision: 3,
    pipSize: "0.01",
    tickSize: "0.001",
    contractSize: "100000",
    pointValueCents: 10000,
  },
  {
    symbol: "EURAUD",
    displayName: "Euro / Australian Dollar",
    market: "forex",
    category: "Minor Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },
  {
    symbol: "GBPAUD",
    displayName: "British Pound / Australian Dollar",
    market: "forex",
    category: "Minor Pairs",
    pricePrecision: 5,
    pipSize: "0.0001",
    tickSize: "0.00001",
    contractSize: "100000",
    pointValueCents: 100,
  },

  /* ── Metals ───────────────────────────────────────────────────── */
  {
    symbol: "XAUUSD",
    displayName: "Gold / US Dollar",
    market: "gold",
    category: "Metals",
    pricePrecision: 2,
    pipSize: "0.01",
    tickSize: "0.01",
    contractSize: "100",
    pointValueCents: 100,
  },
  {
    symbol: "XAGUSD",
    displayName: "Silver / US Dollar",
    market: "gold",
    category: "Metals",
    pricePrecision: 3,
    pipSize: "0.001",
    tickSize: "0.001",
    contractSize: "5000",
    pointValueCents: 500,
  },

  /* ── Indices (CFD-style: 1 contract = $1 per point unless noted) ── */
  {
    symbol: "NAS100",
    displayName: "US Tech 100 (NASDAQ)",
    market: "indices",
    category: "US Indices",
    pricePrecision: 1,
    pipSize: "1",
    tickSize: "0.25",
    contractSize: "1",
    pointValueCents: 25,
  },
  {
    symbol: "US30",
    displayName: "Wall Street 30 (Dow Jones)",
    market: "indices",
    category: "US Indices",
    pricePrecision: 1,
    pipSize: "1",
    tickSize: "1",
    contractSize: "1",
    pointValueCents: 100,
  },
  {
    symbol: "SPX500",
    displayName: "US 500 (S&P 500)",
    market: "indices",
    category: "US Indices",
    pricePrecision: 1,
    pipSize: "0.1",
    tickSize: "0.1",
    contractSize: "1",
    pointValueCents: 10,
  },
  {
    symbol: "GER40",
    displayName: "Germany 40 (DAX)",
    market: "indices",
    category: "EU Indices",
    pricePrecision: 1,
    pipSize: "0.1",
    tickSize: "0.1",
    contractSize: "1",
    pointValueCents: 10,
  },
  {
    symbol: "UK100",
    displayName: "UK 100 (FTSE)",
    market: "indices",
    category: "EU Indices",
    pricePrecision: 1,
    pipSize: "0.1",
    tickSize: "0.1",
    contractSize: "1",
    pointValueCents: 10,
  },

  /* ── Futures (CME-style contracts) ─────────────────────────────── */
  {
    symbol: "NQ",
    displayName: "E-mini Nasdaq 100 Futures",
    market: "futures",
    category: "Equity Index Futures",
    pricePrecision: 2,
    pipSize: "0.25",
    tickSize: "0.25",
    contractSize: "20",
    pointValueCents: 500,
  },
  {
    symbol: "ES",
    displayName: "E-mini S&P 500 Futures",
    market: "futures",
    category: "Equity Index Futures",
    pricePrecision: 2,
    pipSize: "0.25",
    tickSize: "0.25",
    contractSize: "50",
    pointValueCents: 1250,
  },
  {
    symbol: "YM",
    displayName: "E-mini Dow Futures",
    market: "futures",
    category: "Equity Index Futures",
    pricePrecision: 0,
    pipSize: "1",
    tickSize: "1",
    contractSize: "5",
    pointValueCents: 500,
  },
  {
    symbol: "CL",
    displayName: "Crude Oil Futures",
    market: "futures",
    category: "Energy Futures",
    pricePrecision: 2,
    pipSize: "0.01",
    tickSize: "0.01",
    contractSize: "1000",
    pointValueCents: 1000000,
  },
  {
    symbol: "GC",
    displayName: "Gold Futures (COMEX)",
    market: "futures",
    category: "Metal Futures",
    pricePrecision: 1,
    pipSize: "0.1",
    tickSize: "0.1",
    contractSize: "100",
    pointValueCents: 1000,
  },

  /* ── Crypto ───────────────────────────────────────────────────── */
  {
    symbol: "BTCUSD",
    displayName: "Bitcoin / US Dollar",
    market: "crypto",
    category: "Crypto",
    pricePrecision: 2,
    pipSize: "0.01",
    tickSize: "0.01",
    contractSize: "1",
    pointValueCents: 100,
  },
  {
    symbol: "ETHUSD",
    displayName: "Ethereum / US Dollar",
    market: "crypto",
    category: "Crypto",
    pricePrecision: 2,
    pipSize: "0.01",
    tickSize: "0.01",
    contractSize: "1",
    pointValueCents: 100,
  },
];

/* ------------------------------------------------------------------ */
/* Lookup maps (built once, O(1) access)                              */
/* ------------------------------------------------------------------ */

const CATALOG_BY_SYMBOL: ReadonlyMap<string, InstrumentDef> = new Map(
  INSTRUMENT_CATALOG.map((def) => [def.symbol, def]),
);

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/**
 * Normalize a raw user-typed symbol: trim surrounding whitespace and
 * convert to uppercase. Returns "" for null/undefined input. Does NOT
 * validate that the symbol exists in the catalog — callers may use this
 * to canonicalize custom symbols too.
 *
 *   normalizeSymbol("  eurusd ")  → "EURUSD"
 *   normalizeSymbol("nq")         → "NQ"
 *   normalizeSymbol(null)          → ""
 */
export function normalizeSymbol(symbol: string | null | undefined): string {
  if (symbol == null) return "";
  return String(symbol).trim().toUpperCase();
}

/**
 * Look up an instrument definition by symbol. The input is normalized
 * (trimmed + uppercased) before lookup, so callers can pass raw user input
 * directly. Returns `null` if the symbol isn't in the static catalog —
 * callers should treat this as a custom instrument.
 *
 *   findInstrument("eurusd")  → InstrumentDef
 *   findInstrument("XYZABC")  → null
 */
export function findInstrument(
  symbol: string | null | undefined,
): InstrumentDef | null {
  const key = normalizeSymbol(symbol);
  if (!key) return null;
  return CATALOG_BY_SYMBOL.get(key) ?? null;
}

/**
 * Build a synthetic `InstrumentDef` for a custom symbol that isn't in the
 * catalog. Uses sensible defaults: 2-decimal precision, 0.01 pip/tick,
 * contractSize 1, pointValueCents 100 (1:1 with price — works for stocks
 * and most retail crypto CFDs).
 *
 * Used by the InstrumentSelector and the trade form when the user types a
 * symbol that isn't pre-registered.
 */
export function makeCustomInstrument(symbol: string): InstrumentDef {
  const key = normalizeSymbol(symbol);
  return {
    symbol: key,
    displayName: key,
    market: "custom",
    category: "Custom",
    pricePrecision: 2,
    pipSize: "0.01",
    tickSize: "0.01",
    contractSize: "1",
    pointValueCents: 100,
  };
}

/**
 * Resolve an instrument definition from a symbol, falling back to a
 * synthetic custom def if the symbol isn't in the catalog. Never returns
 * null — always yields a usable `InstrumentDef`.
 */
export function resolveInstrument(symbol: string | null | undefined): InstrumentDef {
  const found = findInstrument(symbol);
  if (found) return found;
  return makeCustomInstrument(normalizeSymbol(symbol));
}

/**
 * The unit label to display for stop-distance / R-multiple readouts, by
 * market. Forex uses "pips", futures use "ticks", indices use "points",
 * and everything else falls back to "points" (which is the most neutral
 * term for a price-increment unit).
 */
export function unitLabel(market: InstrumentMarket | string | null | undefined): string {
  switch (market) {
    case "forex":
      return "pips";
    case "futures":
      return "ticks";
    case "indices":
    case "gold":
    case "crypto":
    case "stocks":
      return "points";
    default:
      return "points";
  }
}

/**
 * Convert a price distance (e.g. |entry − stop|) into the instrument's
 * native unit count (pips / ticks / points). Returns 0 for non-finite
 * inputs or when pipSize can't be parsed. The result is rounded to a
 * sensible number of decimals to avoid floating-point dust.
 *
 *   distanceInUnits(0.0010, "0.0001") → 10          (10 pips)
 *   distanceInUnits(2.50,    "0.25")  → 10          (10 ticks)
 *   distanceInUnits(5.0,     "1")     → 5           (5 points)
 */
export function distanceInUnits(
  distance: number | string | null | undefined,
  pipSize: string | null | undefined,
): number {
  if (distance == null || distance === "") return 0;
  const d = typeof distance === "string" ? Number(distance) : distance;
  if (!Number.isFinite(d)) return 0;
  const ps = Number(pipSize ?? "0.01");
  if (!Number.isFinite(ps) || ps <= 0) return 0;
  const units = d / ps;
  // Round to 4 dp to drop float noise (e.g. 9.999999998 → 10).
  return Math.round(units * 10000) / 10000;
}
