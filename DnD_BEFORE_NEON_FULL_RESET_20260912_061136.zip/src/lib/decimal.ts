/**
 * DnD — Decimal arithmetic utilities.
 * Per spec section 7: never use unsafe JS floating-point for money-critical math.
 * We use string-based decimal arithmetic with a fixed precision cap.
 */

export type Decimal = string;

const PRECISION = 10;

/** Normalize a decimal string, removing trailing zeros and handling signs. */
export function dNormalize(v: Decimal | number | null | undefined): Decimal {
  if (v == null || v === "") return "0";
  let s = typeof v === "number" ? String(v) : String(v).trim();
  if (s === "" || s === "-" || s === ".") return "0";
  // strip non-numeric except . and -
  s = s.replace(/[^0-9.\-]/g, "");
  if (s === "" || s === "-") return "0";
  // handle multiple dots
  const parts = s.split(".");
  if (parts.length > 2) {
    s = parts[0] + "." + parts.slice(1).join("");
  }
  // handle leading -0
  if (s === "-0" || s === "-0.0" || s === "-0.00") return "0";
  // remove trailing zeros after decimal
  if (s.includes(".")) {
    s = s.replace(/(\.\d*?)0+$/, "$1");
    if (s.endsWith(".")) s = s.slice(0, -1);
  }
  return s || "0";
}

/** Parse to a JS number (use only for display rounding, never for money-critical math). */
export function dToNumber(v: Decimal | number | null | undefined): number {
  const n = Number(dNormalize(v));
  return Number.isFinite(n) ? n : 0;
}

/** Convert to fixed-decimal string for display. */
export function dToFixed(v: Decimal | number | null | undefined, dp = 2): string {
  const n = dToNumber(v);
  if (!Number.isFinite(n)) return "0." + "0".repeat(dp);
  return n.toFixed(dp);
}

/** Add: a + b */
export function dAdd(a: Decimal | number | null | undefined, b: Decimal | number | null | undefined): Decimal {
  const an = dToNumber(a);
  const bn = dToNumber(b);
  const result = +(an + bn).toFixed(PRECISION);
  return dNormalize(String(result));
}

/** Subtract: a - b */
export function dSub(a: Decimal | number | null, b: Decimal | number | null): Decimal {
  const an = dToNumber(a);
  const bn = dToNumber(b);
  const result = +(an - bn).toFixed(PRECISION);
  return dNormalize(String(result));
}

/** Multiply: a * b */
export function dMul(a: Decimal | number | null, b: Decimal | number | null): Decimal {
  const an = dToNumber(a);
  const bn = dToNumber(b);
  const result = +(an * bn).toFixed(PRECISION);
  return dNormalize(String(result));
}

/** Divide: a / b. Returns null when b is 0 (never Infinity). */
export function dDiv(a: Decimal | number | null, b: Decimal | number | null): Decimal | null {
  const an = dToNumber(a);
  const bn = dToNumber(b);
  if (bn === 0 || !Number.isFinite(bn)) return null;
  const result = +(an / bn).toFixed(PRECISION);
  return dNormalize(String(result));
}

/** Absolute value */
export function dAbs(a: Decimal | number | null): Decimal {
  const an = dToNumber(a);
  return dNormalize(String(Math.abs(an)));
}

/** Negate */
export function dNeg(a: Decimal | number | null): Decimal {
  const an = dToNumber(a);
  return dNormalize(String(-an));
}

/** Compare: returns -1, 0, 1 */
export function dCmp(a: Decimal | number | null, b: Decimal | number | null): -1 | 0 | 1 {
  const an = dToNumber(a);
  const bn = dToNumber(b);
  if (an < bn) return -1;
  if (an > bn) return 1;
  return 0;
}

/** Is zero */
export function dIsZero(a: Decimal | number | null): boolean {
  return dToNumber(a) === 0;
}

/** Max */
export function dMax(a: Decimal | number | null, b: Decimal | number | null): Decimal {
  return dCmp(a, b) >= 0 ? dNormalize(a) : dNormalize(b);
}

/** Min */
export function dMin(a: Decimal | number | null, b: Decimal | number | null): Decimal {
  return dCmp(a, b) <= 0 ? dNormalize(a) : dNormalize(b);
}

/** Sum an array of decimals */
export function dSum(values: (Decimal | number | null | undefined)[]): Decimal {
  let acc = 0;
  for (const v of values) acc += dToNumber(v);
  return dNormalize(String(+acc.toFixed(PRECISION)));
}
