/**
 * DnD — Financial calculation engine.
 * Pure functions. Authoritative server-side computation per spec section 31.
 * NEVER produces NaN or Infinity (spec section 110).
 */

import {
  Decimal,
  dAdd, dSub, dMul, dDiv, dAbs, dCmp, dNormalize, dIsZero, dToNumber, dMax,
} from "./decimal";
import { Cents, toCents, addCents, subCents, negCents } from "./money";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type Direction = "long" | "short";
export type TradeStatus = "open" | "win" | "loss" | "breakeven" | "partial_win" | "partial_loss" | "cancelled";

export interface ExecutionFill {
  kind: "entry" | "exit";
  price: Decimal;
  quantity: Decimal;
  timestamp?: string;
  notes?: string;
}

export interface TradeCalcInput {
  direction: Direction;
  plannedEntryPrice?: Decimal | null;
  plannedStopPrice?: Decimal | null;
  plannedTargetPrice?: Decimal | null;
  fills: ExecutionFill[];
  feesCents?: Cents;
  commissionCents?: Cents;
  swapCents?: Cents;
  slippageCents?: Cents;
  contractSize?: Decimal; // e.g. 100000 for standard forex lot
  pipSize?: Decimal; // e.g. 0.0001 for forex
  /**
   * Value per 1.0 price unit per 1.0 quantity, in cents.
   * Defaults to 100 (i.e. $1 per 1.0 price move per 1.0 qty) — backward compatible
   * with the original hardcoded behaviour for stocks/crypto where price * qty
   * directly equals the dollar P&L. Callers may override this with an
   * instrument-derived value (see `computePointValueCents` below) so that
   * forex/metals/indices/futures whose "1.0 price move" semantics differ from
   * a 1-share stock are scaled correctly.
   */
  pointValueCents?: Cents;
}

/**
 * Compute an instrument-aware `pointValueCents` from the Instrument's stored
 * spec fields. The returned value represents the dollar value (in cents) of a
 * single tick (or pip, when no tickSize is set) per 1.0 contract.
 *
 * - Forex (e.g. 100000 * 0.0001 * 100 = 1000 cents = $10 per pip per lot)
 * - Gold/metals, indices, futures: contractSize * tickSize * 100
 * - Crypto/stocks (contractSize 1, tickSize 0.01): falls back to 100 to keep
 *   the 1:1 price-to-dollar semantics that the default 100 already provides.
 *
 * All inputs are decimal strings (per spec §7); non-numeric values are
 * coerced to 0 so the result is always a finite, non-NaN integer.
 */
export function computePointValueCents(
  contractSize: string | number | null | undefined,
  tickSize: string | number | null | undefined,
  pipSize: string | number | null | undefined,
): Cents {
  const cs = Number(contractSize ?? "1");
  const ts = Number(tickSize ?? pipSize ?? "0.01");
  if (!Number.isFinite(cs) || !Number.isFinite(ts)) return 100;
  const cents = Math.round(cs * ts * 100);
  // For instruments where contractSize * tickSize rounds to ≤1 cent (e.g.
  // 1-share stocks with a 0.01 tick → 1 cent), preserve the historical
  // 1:1-with-price default of 100 cents so existing stock/crypto P&L math is
  // unaffected. Only non-trivial contracts (forex/metals/indices/futures)
  // produce a derived value > 100 and therefore change behaviour.
  if (!Number.isFinite(cents) || cents <= 1) return 100;
  return cents;
}

export interface TradeCalcResult {
  entryPriceAvg: Decimal | null;
  exitPriceAvg: Decimal | null;
  totalQuantity: Decimal | null;
  grossPnlCents: Cents;
  totalCostsCents: Cents;
  netPnlCents: Cents;
  stopDistance: Decimal | null;
  targetDistance: Decimal | null;
  plannedRR: Decimal | null;
  actualR: Decimal | null;
  riskAmountCents: Cents | null;
  rewardAmountCents: Cents | null;
  status: TradeStatus;
}

// ---------------------------------------------------------------------------
// Psychology tag parsing (spec section 22 — psychBeforeJson shape)
// ---------------------------------------------------------------------------

/**
 * Extract mood-tag strings from a `psychBeforeJson` (or `psychAfterJson`)
 * column. The column is stored as a JSON **object** whose `moodTags` field is
 * an array of strings (per spec section 38), but legacy rows may store a
 * bare array — both shapes are supported. Any other shape yields `[]`.
 *
 * Never throws: malformed JSON, null, or unexpected shapes degrade to `[]`.
 */
export function safeParsePsychTags(json: string | null | undefined): string[] {
  if (!json) return [];
  let v: unknown;
  try {
    v = JSON.parse(json);
  } catch {
    return [];
  }
  if (Array.isArray(v)) {
    // Backward-compat: legacy rows stored a bare array of tags.
    return v.filter((x): x is string => typeof x === "string");
  }
  if (v && typeof v === "object") {
    const tags = (v as { moodTags?: unknown }).moodTags;
    if (Array.isArray(tags)) {
      return tags.filter((x): x is string => typeof x === "string");
    }
  }
  return [];
}

// ---------------------------------------------------------------------------
// Core: compute trade P&L from execution ledger (spec section 33)
// ---------------------------------------------------------------------------

/**
 * Calculate the gross P&L in cents from a list of fills.
 * Method: volume-weighted average entry and exit prices, signed by direction.
 * gross = (exitAvg - entryAvg) * qty * contractSize * pointValue  (long)
 * gross = (entryAvg - exitAvg) * qty * contractSize * pointValue  (short)
 * Only matches qty between entries and exits.
 */
export function calculateTradePnl(input: TradeCalcInput): TradeCalcResult {
  const contractSize = input.contractSize ?? "1";
  const pointValueCents = input.pointValueCents ?? 100; // default 1.00 per 1.0 qty per 1.0 price

  const entries = input.fills.filter((f) => f.kind === "entry");
  const exits = input.fills.filter((f) => f.kind === "exit");

  // Volume-weighted average entry price
  const entryAvg = vwap(entries);
  const exitAvg = vwap(exits);

  // Matched quantity (min of total entry qty and total exit qty)
  const entryQty = sumQty(entries);
  const exitQty = sumQty(exits);
  const matchedQty = dCmp(entryQty, exitQty) <= 0 ? entryQty : exitQty;

  let grossPnlCents: Cents = 0;
  if (!dIsZero(matchedQty) && entryAvg && exitAvg) {
    // price diff * matchedQty * contractSize * pointValue
    const diff = input.direction === "long"
      ? dSub(exitAvg, entryAvg)
      : dSub(entryAvg, exitAvg);
    const grossDecimal = dMul(dMul(dMul(diff, matchedQty), contractSize), dNormalize(String(pointValueCents / 100)));
    // convert decimal dollars to cents
    grossPnlCents = toCents(dToNumber(grossDecimal));
  }

  // Costs
  const fees = input.feesCents ?? 0;
  const commission = input.commissionCents ?? 0;
  const swap = input.swapCents ?? 0;
  const slippage = input.slippageCents ?? 0;
  const totalCostsCents = addCents(addCents(addCents(fees, commission), swap), slippage);

  // Net = gross - costs (costs always reduce PnL)
  const netPnlCents = subCents(grossPnlCents, totalCostsCents);

  // Stop & target distances
  const stopDistance = (input.plannedStopPrice && input.plannedEntryPrice && !dIsZero(dSub(input.plannedEntryPrice, input.plannedStopPrice)))
    ? dAbs(dSub(input.plannedEntryPrice, input.plannedStopPrice))
    : null;
  const targetDistance = (input.plannedTargetPrice && input.plannedEntryPrice && !dIsZero(dSub(input.plannedTargetPrice, input.plannedEntryPrice)))
    ? dAbs(dSub(input.plannedTargetPrice, input.plannedEntryPrice))
    : null;

  // Planned R:R
  const plannedRR = (stopDistance && targetDistance)
    ? dDiv(targetDistance, stopDistance)
    : null;

  // Risk amount: stopDistance * plannedQty * contractSize * pointValue
  // We use entryQty as plannedQty (or matchedQty fallback)
  const plannedQty = entryQty;
  let riskAmountCents: Cents | null = null;
  let rewardAmountCents: Cents | null = null;
  if (stopDistance && !dIsZero(plannedQty)) {
    const riskDecimal = dMul(dMul(dMul(stopDistance, plannedQty), contractSize), dNormalize(String(pointValueCents / 100)));
    riskAmountCents = toCents(dToNumber(riskDecimal));
  }
  if (targetDistance && !dIsZero(plannedQty)) {
    const rewardDecimal = dMul(dMul(dMul(targetDistance, plannedQty), contractSize), dNormalize(String(pointValueCents / 100)));
    rewardAmountCents = toCents(dToNumber(rewardDecimal));
  }

  // Actual R: net / risk
  let actualR: Decimal | null = null;
  if (riskAmountCents && riskAmountCents > 0) {
    actualR = dDiv(String(netPnlCents / 100), String(riskAmountCents / 100));
  }

  // Status
  const status = deriveStatus(netPnlCents, entryQty, exitQty);

  return {
    entryPriceAvg: entryAvg,
    exitPriceAvg: exitAvg,
    totalQuantity: plannedQty,
    grossPnlCents,
    totalCostsCents,
    netPnlCents,
    stopDistance,
    targetDistance,
    plannedRR,
    actualR,
    riskAmountCents,
    rewardAmountCents,
    status,
  };
}

function vwap(fills: ExecutionFill[]): Decimal | null {
  if (fills.length === 0) return null;
  let pq = 0; // sum of price*qty
  let q = 0;  // sum of qty
  for (const f of fills) {
    const p = dToNumber(f.price);
    const qt = dToNumber(f.quantity);
    if (!Number.isFinite(p) || !Number.isFinite(qt)) continue;
    pq += p * qt;
    q += qt;
  }
  if (q === 0) return null;
  return dNormalize(String(+(pq / q).toFixed(10)));
}

function sumQty(fills: ExecutionFill[]): Decimal {
  let s = 0;
  for (const f of fills) s += dToNumber(f.quantity);
  return dNormalize(String(+s.toFixed(10)));
}

function deriveStatus(netPnl: Cents, entryQty: Decimal, exitQty: Decimal): TradeStatus {
  if (dIsZero(entryQty)) return "open";
  if (dIsZero(exitQty)) return "open";
  const cmp = dCmp(exitQty, entryQty);
  if (cmp < 0) {
    return netPnl > 0 ? "partial_win" : netPnl < 0 ? "partial_loss" : "breakeven";
  }
  if (netPnl > 0) return "win";
  if (netPnl < 0) return "loss";
  return "breakeven";
}

// ---------------------------------------------------------------------------
// Position sizing (spec section 79)
// ---------------------------------------------------------------------------

export interface PositionSizeInput {
  accountBalanceCents: Cents;
  riskPct: Decimal;       // e.g. 0.005 for 0.5%
  entryPrice: Decimal;
  stopPrice: Decimal;
  contractSize: Decimal;
  pointValueCents: Cents;
}

export interface PositionSizeResult {
  riskAmountCents: Cents;
  stopDistance: Decimal;
  positionSize: Decimal | null;
  plannedLossCents: Cents;
  plannedRewardCents: Cents | null; // only if target provided
}

export function calculatePositionSize(input: PositionSizeInput): PositionSizeResult {
  const riskAmountCents = Math.round((input.accountBalanceCents * dToNumber(input.riskPct)) / 100) * 100 / 100;
  // careful: Math.round(balance * pct) gives cents directly
  const riskCents = Math.round((input.accountBalanceCents / 100) * dToNumber(input.riskPct) * 100);
  const stopDistance = dAbs(dSub(input.entryPrice, input.stopPrice));
  // position size = riskAmount / (stopDistance * contractSize * pointValue)
  let positionSize: Decimal | null = null;
  if (!dIsZero(stopDistance)) {
    const denom = dToNumber(dMul(dMul(stopDistance, input.contractSize), dNormalize(String(input.pointValueCents / 100))));
    if (denom > 0) {
      positionSize = dDiv(String(riskCents / 100), String(denom));
    }
  }
  return {
    riskAmountCents: riskCents,
    stopDistance,
    positionSize,
    plannedLossCents: negCents(riskCents),
    plannedRewardCents: null,
  };
}

// ---------------------------------------------------------------------------
// Aggregate metrics (spec section 70)
// ---------------------------------------------------------------------------

export interface TradeMetricRow {
  id: string;
  netPnlCents: Cents;
  actualR: Decimal | null;
  status: TradeStatus;
  entryTime?: Date | string | null;
  setupGrade?: string | null;
  instrumentSymbol?: string;
  session?: string | null;
  strategyId?: string | null;
  strategyVersionId?: string | null;
  behaviorFlags?: string[];
  psychTags?: string[];
  ruleCompliant?: boolean;
}

export interface AggregateMetrics {
  totalTrades: number;
  closedTrades: number;
  wins: number;
  losses: number;
  breakevens: number;
  winRate: Decimal | null;
  totalPnlCents: Cents;
  avgPnlCents: Cents | null;
  avgWinCents: Cents | null;
  avgLossCents: Cents | null;
  avgR: Decimal | null;
  expectancyR: Decimal | null;
  profitFactor: Decimal | null;
  maxDrawdownCents: Cents;
  currentDrawdownCents: Cents;
  largestWinCents: Cents;
  largestLossCents: Cents;
  consecutiveWins: number;
  consecutiveLosses: number;
  recoveryPeriod: number | null;
}

export function computeAggregateMetrics(trades: TradeMetricRow[]): AggregateMetrics {
  const closed = trades.filter((t) => t.status !== "open" && t.status !== "cancelled" && t.status !== "planned");
  const wins = closed.filter((t) => t.netPnlCents > 0);
  const losses = closed.filter((t) => t.netPnlCents < 0);
  const bes = closed.filter((t) => t.netPnlCents === 0);

  const totalPnl = closed.reduce((s, t) => s + t.netPnlCents, 0);

  const winRate = closed.length > 0 ? dNormalize(String(wins.length / closed.length)) : null;

  const avgPnl = closed.length > 0 ? Math.round(totalPnl / closed.length) : null;

  const avgWin = wins.length > 0 ? Math.round(wins.reduce((s, t) => s + t.netPnlCents, 0) / wins.length) : null;
  const avgLoss = losses.length > 0 ? Math.round(losses.reduce((s, t) => s + t.netPnlCents, 0) / losses.length) : null;

  // Avg R over trades with valid R
  const rValues = closed.map((t) => t.actualR).filter((r): r is Decimal => r != null && Number.isFinite(dToNumber(r)));
  const avgR = rValues.length > 0 ? dNormalize(String(+(rValues.reduce((s, r) => s + dToNumber(r), 0) / rValues.length).toFixed(10))) : null;

  // Expectancy = avg realized R (per spec section 73)
  const expectancyR = avgR;

  // Profit factor (spec section 72): gross profits / abs(gross losses)
  const grossProfit = wins.reduce((s, t) => s + t.netPnlCents, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.netPnlCents, 0));
  const profitFactor = grossLoss > 0 ? dNormalize(String(+(grossProfit / grossLoss).toFixed(10))) : null;

  // Drawdown (spec section 71): from equity curve
  const sorted = [...closed].sort((a, b) => {
    const ad = a.entryTime ? new Date(a.entryTime).getTime() : 0;
    const bd = b.entryTime ? new Date(b.entryTime).getTime() : 0;
    return ad - bd;
  });
  let equity = 0;
  let peak = 0;
  let maxDD = 0;
  let currentDD = 0;
  let recoveryStart: number | null = null;
  let recoveryPeriod: number | null = null;
  let inDD = false;
  let ddStartIdx = -1;
  for (let i = 0; i < sorted.length; i++) {
    equity += sorted[i].netPnlCents;
    if (equity > peak) {
      peak = equity;
      if (inDD) {
        // recovered
        inDD = false;
        recoveryPeriod = recoveryStart != null ? i - recoveryStart : null;
        recoveryStart = null;
      }
    }
    const dd = peak - equity;
    if (dd > maxDD) maxDD = dd;
    currentDD = dd;
    if (dd > 0 && !inDD) {
      inDD = true;
      recoveryStart = i;
    }
  }

  const largestWin = wins.length > 0 ? Math.max(...wins.map((t) => t.netPnlCents)) : 0;
  const largestLoss = losses.length > 0 ? Math.min(...losses.map((t) => t.netPnlCents)) : 0;

  // Streaks
  let cw = 0, cl = 0, maxCw = 0, maxCl = 0;
  for (const t of sorted) {
    if (t.netPnlCents > 0) { cw++; cl = 0; maxCw = Math.max(maxCw, cw); }
    else if (t.netPnlCents < 0) { cl++; cw = 0; maxCl = Math.max(maxCl, cl); }
    else { cw = 0; cl = 0; }
  }

  return {
    totalTrades: trades.length,
    closedTrades: closed.length,
    wins: wins.length,
    losses: losses.length,
    breakevens: bes.length,
    winRate,
    totalPnlCents: totalPnl,
    avgPnlCents: avgPnl,
    avgWinCents: avgWin,
    avgLossCents: avgLoss,
    avgR,
    expectancyR,
    profitFactor,
    maxDrawdownCents: maxDD,
    currentDrawdownCents: currentDD,
    largestWinCents: largestWin,
    largestLossCents: largestLoss,
    consecutiveWins: maxCw,
    consecutiveLosses: maxCl,
    recoveryPeriod,
  };
}

// ---------------------------------------------------------------------------
// Equity curve (spec section 22)
// ---------------------------------------------------------------------------

export interface EquityPoint {
  date: string; // ISO date
  label: string;
  pnlCents: Cents;
  cumulativeCents: Cents;
  tradeId: string;
}

export function buildEquityCurve(trades: TradeMetricRow[], startingBalanceCents: Cents = 0): EquityPoint[] {
  const sorted = [...trades]
    .filter((t) => t.status !== "open" && t.status !== "cancelled" && t.status !== "planned" && t.entryTime)
    .sort((a, b) => new Date(a.entryTime!).getTime() - new Date(b.entryTime!).getTime());
  let cumulative = startingBalanceCents;
  return sorted.map((t) => {
    cumulative += t.netPnlCents;
    const d = new Date(t.entryTime!);
    return {
      date: d.toISOString(),
      label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      pnlCents: t.netPnlCents,
      cumulativeCents: cumulative,
      tradeId: t.id,
    };
  });
}

// ---------------------------------------------------------------------------
// Daily P&L aggregation (spec section 22)
// ---------------------------------------------------------------------------

export interface DailyPnlPoint {
  date: string;
  label: string;
  pnlCents: Cents;
  tradeCount: number;
}

export function buildDailyPnl(trades: TradeMetricRow[]): DailyPnlPoint[] {
  const map = new Map<string, { pnl: Cents; count: number; ts: number }>();
  for (const t of trades) {
    if (!t.entryTime) continue;
    const d = new Date(t.entryTime);
    const key = d.toISOString().slice(0, 10);
    const entry = map.get(key) ?? { pnl: 0, count: 0, ts: d.getTime() };
    entry.pnl += t.netPnlCents;
    entry.count += 1;
    map.set(key, entry);
  }
  return [...map.entries()]
    .sort((a, b) => a[1].ts - b[1].ts)
    .map(([date, e]) => ({
      date,
      label: new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      pnlCents: e.pnl,
      tradeCount: e.count,
    }));
}

// ---------------------------------------------------------------------------
// R distribution (spec section 22)
// ---------------------------------------------------------------------------

export interface RDistributionBucket {
  bucket: string;
  count: number;
  minR: number;
  maxR: number;
}

export function buildRDistribution(trades: TradeMetricRow[]): RDistributionBucket[] {
  const buckets: { min: number; max: number; label: string }[] = [
    { min: -Infinity, max: -2, label: "≤ -2R" },
    { min: -2, max: -1, label: "-2 to -1R" },
    { min: -1, max: 0, label: "-1 to 0R" },
    { min: 0, max: 0.0001, label: "BE" },
    { min: 0.0001, max: 1, label: "0 to +1R" },
    { min: 1, max: 2, label: "+1 to +2R" },
    { min: 2, max: Infinity, label: "≥ +2R" },
  ];
  return buckets.map((b) => {
    const count = trades.filter((t) => {
      if (t.actualR == null) return false;
      const r = dToNumber(t.actualR);
      if (b.min === 0 && b.max === 0.0001) return r === 0;
      if (b.min === -Infinity) return r <= b.max;
      if (b.max === Infinity) return r > b.min;
      return r > b.min && r <= b.max;
    }).length;
    return { bucket: b.label, count, minR: b.min, maxR: b.max };
  });
}

// ---------------------------------------------------------------------------
// Group-by analytics (spec sections 75, 76, 74)
// ---------------------------------------------------------------------------

export interface GroupBreakdown {
  key: string;
  label: string;
  trades: number;
  wins: number;
  winRate: Decimal | null;
  avgR: Decimal | null;
  expectancyR: Decimal | null;
  pnlCents: Cents;
}

export function groupBy<T extends TradeMetricRow>(
  trades: T[],
  keyFn: (t: T) => string | null | undefined,
  labelFn: (k: string) => string = (k) => k,
): GroupBreakdown[] {
  const groups = new Map<string, T[]>();
  for (const t of trades) {
    const k = keyFn(t);
    if (k == null) continue;
    const arr = groups.get(k) ?? [];
    arr.push(t);
    groups.set(k, arr);
  }
  return [...groups.entries()].map(([key, arr]) => {
    const m = computeAggregateMetrics(arr);
    return {
      key,
      label: labelFn(key),
      trades: m.totalTrades,
      wins: m.wins,
      winRate: m.winRate,
      avgR: m.avgR,
      expectancyR: m.expectancyR,
      pnlCents: m.totalPnlCents,
    };
  }).sort((a, b) => b.trades - a.trades);
}

// ---------------------------------------------------------------------------
// Sample-size-aware insights (spec sections 23, 24, 137, 138)
// ---------------------------------------------------------------------------

export interface Insight {
  id: string;
  title: string;
  body: string;
  sampleSize: number;
  metric: string;
  bucketLabel: string;
  comparison?: string;
  tradeIds: string[];
  warning?: "low_sample" | "missing_data";
}

export function generateInsights(trades: TradeMetricRow[], minSample = 10): Insight[] {
  const insights: Insight[] = [];
  const closed = trades.filter((t) => t.status !== "open" && t.status !== "cancelled" && t.status !== "planned");
  if (closed.length < minSample) {
    if (closed.length > 0) {
      insights.push({
        id: "low-sample",
        title: "Not enough data yet",
        body: `You have ${closed.length} closed trade${closed.length === 1 ? "" : "s"}. DnD starts generating statistical insights once you have at least ${minSample} closed trades, so patterns you see now may not be reliable.`,
        sampleSize: closed.length,
        metric: "samples",
        bucketLabel: "all",
        tradeIds: closed.map((t) => t.id),
        warning: "low_sample",
      });
    }
    return insights;
  }

  // Behavior flag insights
  const allFlags = new Set<string>();
  closed.forEach((t) => t.behaviorFlags?.forEach((f) => allFlags.add(f)));
  for (const flag of allFlags) {
    const withFlag = closed.filter((t) => t.behaviorFlags?.includes(flag));
    const withoutFlag = closed.filter((t) => !t.behaviorFlags?.includes(flag));
    if (withFlag.length < minSample) continue;
    const withR = withFlag.map((t) => t.actualR).filter((r): r is Decimal => r != null);
    const withoutR = withoutFlag.map((t) => t.actualR).filter((r): r is Decimal => r != null);
    if (withR.length === 0) continue;
    const withAvg = withR.reduce((s, r) => s + dToNumber(r), 0) / withR.length;
    const withoutAvg = withoutR.length > 0 ? withoutR.reduce((s, r) => s + dToNumber(r), 0) / withoutR.length : null;
    const flagLabel = humanizeFlag(flag);
    if (withoutAvg != null && Math.abs(withAvg - withoutAvg) > 0.05) {
      const direction = withAvg < withoutAvg ? "lower" : "higher";
      insights.push({
        id: `flag-${flag}`,
        title: `Trades tagged "${flagLabel}"`,
        body: `Trades tagged "${flagLabel}" have historically produced ${direction} average R (${withAvg.toFixed(2)}R across ${withFlag.length} trades) compared to ${withoutAvg.toFixed(2)}R across ${withoutFlag.length} trades without that flag.`,
        sampleSize: withFlag.length,
        metric: "avgR",
        bucketLabel: flagLabel,
        comparison: `vs ${withoutAvg.toFixed(2)}R`,
        tradeIds: withFlag.map((t) => t.id),
      });
    } else {
      insights.push({
        id: `flag-${flag}`,
        title: `Trades tagged "${flagLabel}"`,
        body: `Trades tagged "${flagLabel}" have an average realized R of ${withAvg.toFixed(2)}R across ${withFlag.length} trades.`,
        sampleSize: withFlag.length,
        metric: "avgR",
        bucketLabel: flagLabel,
        tradeIds: withFlag.map((t) => t.id),
      });
    }
  }

  // Session insights
  const sessions = groupBy(closed, (t) => t.session, (k) => sessionLabel(k));
  for (const s of sessions) {
    if (s.trades < minSample) continue;
    if (s.avgR == null) continue;
    insights.push({
      id: `session-${s.key}`,
      title: `${s.label} session`,
      body: `${s.label} trades have produced an average of ${dToNumber(s.avgR).toFixed(2)}R across ${s.trades} trades, with a ${dToNumber(s.winRate).toFixed(1)}% win rate.`,
      sampleSize: s.trades,
      metric: "avgR",
      bucketLabel: s.label,
      tradeIds: closed.filter((t) => t.session === s.key).map((t) => t.id),
    });
  }

  // A+ vs non-A+
  const aplus = closed.filter((t) => t.setupGrade === "A+");
  const nonAplus = closed.filter((t) => t.setupGrade && t.setupGrade !== "A+" && t.setupGrade !== "Invalid");
  if (aplus.length >= minSample && nonAplus.length >= minSample) {
    const aR = aplus.map((t) => t.actualR).filter((r): r is Decimal => r != null);
    const nR = nonAplus.map((t) => t.actualR).filter((r): r is Decimal => r != null);
    if (aR.length > 0 && nR.length > 0) {
      const aAvg = aR.reduce((s, r) => s + dToNumber(r), 0) / aR.length;
      const nAvg = nR.reduce((s, r) => s + dToNumber(r), 0) / nR.length;
      insights.push({
        id: "aplus-vs-non",
        title: "A+ vs non-A+ setups",
        body: `A+ setups have produced ${aAvg.toFixed(2)}R on average across ${aplus.length} trades, compared to ${nAvg.toFixed(2)}R across ${nonAplus.length} non-A+ trades.`,
        sampleSize: aplus.length + nonAplus.length,
        metric: "avgR",
        bucketLabel: "A+ vs non-A+",
        tradeIds: [...aplus, ...nonAplus].map((t) => t.id),
      });
    }
  }

  return insights.sort((a, b) => b.sampleSize - a.sampleSize);
}

function humanizeFlag(flag: string): string {
  return flag
    .split("_")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

function sessionLabel(s: string): string {
  const map: Record<string, string> = {
    asia: "Asia",
    london: "London",
    ny_am: "New York AM",
    ny_pm: "New York PM",
    custom: "Custom",
  };
  return map[s] ?? s;
}

// ---------------------------------------------------------------------------
// Plan adherence (spec section 23 — planned vs actual execution)
// ---------------------------------------------------------------------------

/**
 * Result of comparing a trade's planned values against its actual execution.
 *
 * `adherenceScore` is a 0–1 number representing the fraction of binary checks
 * (session match, target hit, risk-within-tolerance, positive R achieved) that
 * passed. Checks that can't be evaluated (e.g. no planned session recorded, no
 * target price, no account balance) are excluded from the denominator — so a
 * trade with only one check evaluated and that check passed scores 1.0, not
 * 0.25. If no checks can be evaluated at all, the score is 0.
 */
export interface PlanAdherenceCheck {
  label: string;
  passed: boolean | null;
  detail?: string;
}

export interface PlanAdherence {
  plannedRR: Decimal | null;
  actualRR: Decimal | null;
  plannedRiskPct: Decimal | null;
  actualRiskPct: Decimal | null;
  sessionMatch: boolean | null;
  targetMatch: boolean | null;
  adherenceScore: number;
  adherencePct: number;
  checks: PlanAdherenceCheck[];
}

/**
 * Trade-shape accepted by `calculatePlanAdherence`. Accepts the loose shape
 * produced by Prisma's `Trade` row (decimal strings + nullable fields) plus an
 * optional `accountBalanceCents` so we can derive `actualRiskPct` from the
 * risk amount vs the account balance.
 */
export interface PlanAdherenceTrade {
  direction?: string | null;
  /** Actual session the trade was taken in (from `Trade.session`). */
  session?: string | null;
  /** Planned session (from `setupJson.session` or a daily plan). */
  plannedSession?: string | null;
  plannedEntryPrice?: Decimal | null;
  plannedStopPrice?: Decimal | null;
  plannedTargetPrice?: Decimal | null;
  plannedRiskPct?: Decimal | null;
  entryPriceAvg?: Decimal | null;
  exitPriceAvg?: Decimal | null;
  /** Pre-computed actual R (decimal string). */
  actualR?: Decimal | null;
  /** Risk amount in cents — typically from `calculateTradePnl.riskAmountCents`. */
  riskAmountCents?: number | null;
  /** Account balance in cents — used to derive `actualRiskPct`. */
  accountBalanceCents?: number | null;
}

/**
 * Compute plan adherence for a single trade. Pure function — no I/O.
 *
 * Binary checks (each 0/1 or null when undeterminable):
 *   - `sessionMatch`: planned session === actual session
 *   - `targetMatch`: |exitPrice - target| / |target| <= 5% (within 5% of target)
 *   - `riskWithinTolerance`: actual risk is within 50% of planned risk
 *     (ratio of actual/planned between 0.5 and 1.5)
 *   - `rrAchieved`: actualR > 0 (the trade was profitable)
 *
 * `adherenceScore` = mean of the non-null checks (or 0 if all null).
 */
export function calculatePlanAdherence(trade: PlanAdherenceTrade): PlanAdherence {
  // Planned R:R = |target - entry| / |entry - stop|
  let plannedRR: Decimal | null = null;
  if (trade.plannedEntryPrice && trade.plannedStopPrice && trade.plannedTargetPrice) {
    const stopDist = dAbs(dSub(trade.plannedEntryPrice, trade.plannedStopPrice));
    const targetDist = dAbs(dSub(trade.plannedTargetPrice, trade.plannedEntryPrice));
    if (!dIsZero(stopDist)) {
      plannedRR = dDiv(targetDist, stopDist);
    }
  }

  // Actual R: already computed server-side — normalize and pass through.
  const actualRR: Decimal | null =
    trade.actualR != null && trade.actualR !== "" ? dNormalize(trade.actualR) : null;

  // Planned risk %
  const plannedRiskPct: Decimal | null =
    trade.plannedRiskPct != null && trade.plannedRiskPct !== ""
      ? dNormalize(trade.plannedRiskPct)
      : null;

  // Actual risk %: riskAmount / accountBalance (if both available and balance > 0)
  let actualRiskPct: Decimal | null = null;
  if (
    trade.riskAmountCents != null &&
    trade.accountBalanceCents != null &&
    trade.accountBalanceCents > 0 &&
    trade.riskAmountCents >= 0
  ) {
    actualRiskPct = dDiv(
      String(trade.riskAmountCents / 100),
      String(trade.accountBalanceCents / 100),
    );
  }

  // Session match — null when either planned or actual session is missing.
  const plannedSession = trade.plannedSession ?? null;
  const actualSession = trade.session ?? null;
  const sessionMatch: boolean | null =
    plannedSession && actualSession ? plannedSession === actualSession : null;

  // Target match — exit price within 5% of planned target.
  let targetMatch: boolean | null = null;
  if (trade.exitPriceAvg && trade.plannedTargetPrice) {
    const exit = dToNumber(trade.exitPriceAvg);
    const target = dToNumber(trade.plannedTargetPrice);
    if (Number.isFinite(exit) && Number.isFinite(target) && target !== 0) {
      const deviation = Math.abs(exit - target) / Math.abs(target);
      targetMatch = deviation <= 0.05;
    }
  }

  // Risk-within-tolerance — actual risk is within 50% of planned risk
  // (i.e. ratio of actual/planned is between 0.5 and 1.5).
  let riskWithinTolerance: boolean | null = null;
  if (plannedRiskPct && actualRiskPct) {
    const planned = dToNumber(plannedRiskPct);
    const actual = dToNumber(actualRiskPct);
    if (planned > 0) {
      const ratio = actual / planned;
      riskWithinTolerance = ratio >= 0.5 && ratio <= 1.5;
    }
  }

  // R:R achieved — actualR > 0 (i.e. the trade was profitable).
  const rrAchieved: boolean | null =
    actualRR != null ? dToNumber(actualRR) > 0 : null;

  const checks: PlanAdherenceCheck[] = [
    {
      label: "Session match",
      passed: sessionMatch,
      detail:
        sessionMatch === null
          ? "No planned session recorded"
          : sessionMatch
            ? "Traded in the planned session"
            : "Traded outside the planned session",
    },
    {
      label: "Target hit",
      passed: targetMatch,
      detail:
        targetMatch === null
          ? "No target or exit price recorded"
          : targetMatch
            ? "Exit price within 5% of planned target"
            : "Exit price deviated more than 5% from target",
    },
    {
      label: "Risk within tolerance",
      passed: riskWithinTolerance,
      detail:
        riskWithinTolerance === null
          ? "Planned or actual risk unavailable"
          : riskWithinTolerance
            ? "Actual risk within 50% of planned risk"
            : "Actual risk outside 50% tolerance of planned risk",
    },
    {
      label: "Positive R achieved",
      passed: rrAchieved,
      detail:
        rrAchieved === null
          ? "No R-multiple computed"
          : rrAchieved
            ? "Trade was profitable (R > 0)"
            : "Trade was not profitable (R ≤ 0)",
    },
  ];

  // Adherence score: average of non-null binary checks. Each check contributes
  // 1 (passed) or 0 (failed); null checks are excluded from the denominator.
  const evaluatedChecks = checks
    .map((c) => c.passed)
    .filter((v): v is boolean => v !== null);
  const adherenceScore =
    evaluatedChecks.length > 0
      ? evaluatedChecks.reduce((sum, v) => sum + (v ? 1 : 0), 0) / evaluatedChecks.length
      : 0;
  const adherencePct = adherenceScore * 100;

  return {
    plannedRR,
    actualRR,
    plannedRiskPct,
    actualRiskPct,
    sessionMatch,
    targetMatch,
    adherenceScore,
    adherencePct,
    checks,
  };
}
