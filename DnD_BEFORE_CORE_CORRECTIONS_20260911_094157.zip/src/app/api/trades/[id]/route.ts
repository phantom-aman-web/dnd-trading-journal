import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { ok, bad, notFound, toApiError, parseJson } from "@/lib/api";
import { calculateTradePnl, TradeCalcInput, computePointValueCents, ExecutionFill } from "@/lib/calculations";
import {
  evaluateChecklist,
  parseChecklistItems,
  parseGradingThresholds,
  serializeAnswers,
  type ChecklistAnswer,
} from "@/lib/checklist-evaluation";
import { buildSignedUrl } from "@/lib/storage";
import { audit } from "@/lib/audit";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  let user;
  try { user = await requireUser(); } catch (e) { return toApiError(e); }
  const { id } = await ctx.params;
  const trade = await db.trade.findFirst({
    where: { id, userId: user.id },
    include: {
      executions: { orderBy: { seq: "asc" } },
      account: true,
      instrument: true,
      strategy: { include: { versions: { orderBy: { effectiveDate: "desc" } } } },
      strategyVersion: true,
      dailyPlan: true,
      checklistVersion: { include: { checklist: true } },
      checklistEvaluations: {
        include: { checklistVersion: { include: { checklist: true } } },
        orderBy: { evaluatedAt: "desc" },
      },
      media: { include: { annotations: true }, orderBy: { createdAt: "asc" } },
      reviewLinks: { include: { review: true } },
    },
  });
  if (!trade) return notFound("Trade not found");
  // Inline a signed `url` into each media item so the client doesn't need
  // to make N follow-up GET /api/media/[id] requests just to render
  // evidence thumbnails (Fix 3 — media N+1 query).
  const tradeWithUrls = {
    ...trade,
    media: trade.media.map((m) => ({ ...m, url: buildSignedUrl(m.storedPath) })),
  };
  return ok(tradeWithUrls);
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  let user;
  try { user = await requireUser(); } catch (e) { return toApiError(e); }
  const { id } = await ctx.params;
  const trade = await db.trade.findFirst({ where: { id, userId: user.id } });
  if (!trade) return notFound("Trade not found");

  const body = await parseJson(req);
  if (!body) return bad("Invalid JSON body");

  // Mass-assignment protection: explicit allowlist (spec section 102)
  const allowed: Record<string, unknown> = {};
  const fields = [
    "instrumentSymbol", "market", "direction", "status", "session",
    "newsEvent",
    "strategyId", "strategyVersionId", "dailyPlanId", "checklistVersionId",
    "setupGrade", "setupScore", "plannedEntryPrice", "plannedStopPrice", "plannedTargetPrice",
    "plannedRiskPct", "entryTime", "exitTime", "tradingTimezone",
    "feesCents", "commissionCents", "swapCents", "slippageCents",
    "notes", "lessons", "isDraft", "isArchived",
  ];
  for (const f of fields) {
    if (f in body) {
      // Validate FK ownership for relational fields before passing through.
      if (f === "strategyId" && body[f]) {
        const strat = await db.strategy.findFirst({ where: { id: body[f], userId: user.id } });
        if (!strat) return bad("Strategy not found or not owned by user.");
      }
      if (f === "strategyVersionId" && body[f]) {
        const ver = await db.strategyVersion.findFirst({
          where: { id: body[f], strategy: { userId: user.id } },
        });
        if (!ver) return bad("Strategy version not found or not owned by user.");
      }
      if (f === "checklistVersionId" && body[f]) {
        const cv = await db.checklistVersion.findFirst({
          where: { id: body[f], checklist: { userId: user.id } },
        });
        if (!cv) return bad("Checklist version not found or not owned by user.");
      }
      if (f === "dailyPlanId" && body[f]) {
        const plan = await db.dailyPlan.findFirst({ where: { id: body[f], userId: user.id } });
        if (!plan) return bad("Daily plan not found or not owned by user.");
      }
      allowed[f] = body[f];
    }
  }
  if ("tags" in body) allowed.tagsJson = JSON.stringify(body.tags ?? []);
  if ("setup" in body) allowed.setupJson = body.setup ? JSON.stringify(body.setup) : null;
  if ("thesis" in body) allowed.thesisJson = body.thesis ? JSON.stringify(body.thesis) : null;
  if ("planAdherence" in body) allowed.planAdherenceJson = body.planAdherence ? JSON.stringify(body.planAdherence) : null;
  if ("psychBefore" in body) allowed.psychBeforeJson = body.psychBefore ? JSON.stringify(body.psychBefore) : null;
  if ("psychAfter" in body) allowed.psychAfterJson = body.psychAfter ? JSON.stringify(body.psychAfter) : null;
  if ("behaviorFlags" in body) allowed.behaviorFlagsJson = JSON.stringify(body.behaviorFlags ?? []);

  // If executions provided, replace ledger and recompute (spec section 31, 33).
  // P&L is also recomputed when ANY financially-relevant field changes — not
  // just executions. Specifically: executions, feesCents, commissionCents,
  // swapCents, slippageCents, or direction. When `executions` isn't provided,
  // the trade's existing ledger is used as the fill source.
  const hasExecutions = Array.isArray(body.executions);
  const hasFinancialChange =
    hasExecutions ||
    body.feesCents !== undefined ||
    body.commissionCents !== undefined ||
    body.swapCents !== undefined ||
    body.slippageCents !== undefined ||
    body.direction !== undefined;

  if (hasFinancialChange) {
    // Replace the executions ledger if new executions were provided.
    if (hasExecutions) {
      await db.tradeExecution.deleteMany({ where: { tradeId: id } });
      if (body.executions.length > 0) {
        await db.tradeExecution.createMany({
          data: body.executions.map((e: any, idx: number) => ({
            tradeId: id,
            kind: e.kind,
            seq: idx,
            price: String(e.price),
            quantity: String(e.quantity),
            timestamp: e.timestamp ? new Date(e.timestamp) : new Date(),
            notes: e.notes,
          })),
        });
      }
    }

    // Use new executions if provided, otherwise load the trade's existing ledger.
    // Type the array as ExecutionFill[] so the kind literal ("entry" | "exit")
    // is preserved — the previous `kind: string` widening caused a TS2322
    // error when assigning into TradeCalcInput.fills.
    let fills: ExecutionFill[];
    if (hasExecutions) {
      fills = body.executions.map((e: any): ExecutionFill => ({
        kind: e.kind,
        price: String(e.price),
        quantity: String(e.quantity),
      }));
    } else {
      const existingExecs = await db.tradeExecution.findMany({
        where: { tradeId: id },
        orderBy: { seq: "asc" },
      });
      fills = existingExecs.map((e): ExecutionFill => ({
        kind: e.kind as "entry" | "exit",
        price: e.price,
        quantity: e.quantity,
      }));
    }

    const instrument = trade.instrumentId
      ? await db.instrument.findFirst({ where: { id: trade.instrumentId } })
      : null;
    const calcInput: TradeCalcInput = {
      direction: body.direction ?? trade.direction,
      plannedEntryPrice: body.plannedEntryPrice ?? trade.plannedEntryPrice,
      plannedStopPrice: body.plannedStopPrice ?? trade.plannedStopPrice,
      plannedTargetPrice: body.plannedTargetPrice ?? trade.plannedTargetPrice,
      fills,
      feesCents: body.feesCents ?? trade.feesCents,
      commissionCents: body.commissionCents ?? trade.commissionCents,
      swapCents: body.swapCents ?? trade.swapCents,
      slippageCents: body.slippageCents ?? trade.slippageCents,
      contractSize: instrument?.contractSize ?? "1",
      pipSize: instrument?.pipSize ?? "0.0001",
      // Instrument-aware point value (spec §31, §7): derive from the
      // instrument's contractSize + tickSize/pipSize rather than the legacy
      // hardcoded 100.
      pointValueCents: computePointValueCents(
        instrument?.contractSize ?? "1",
        instrument?.tickSize ?? null,
        instrument?.pipSize ?? null,
      ),
    };
    const calc = calculateTradePnl(calcInput);
    allowed.entryPriceAvg = calc.entryPriceAvg;
    allowed.exitPriceAvg = calc.exitPriceAvg;
    allowed.grossPnlCents = calc.grossPnlCents;
    allowed.netPnlCents = calc.netPnlCents;
    allowed.actualR = calc.actualR;
    // Only auto-derive status from executions when the ledger was replaced.
    if (hasExecutions) allowed.status = body.status ?? calc.status;
  }

  // Re-evaluate the A+ checklist when answers are provided. The server
  // computes the authoritative grade/score from the items + answers, updates
  // the trade's setupGrade/setupScore/checklistVersionId, and upserts the
  // TradeChecklistEvaluation row (spec section 41, 102).
  if (
    body.checklistAnswers &&
    typeof body.checklistAnswers === "object" &&
    body.checklistVersionId
  ) {
    const version = await db.checklistVersion.findFirst({
      where: { id: body.checklistVersionId, checklist: { userId: user.id } },
    });
    if (version) {
      const items = parseChecklistItems(version.itemsJson);
      const thresholds = parseGradingThresholds(version.gradingThresholdsJson);
      const answers = body.checklistAnswers as ChecklistAnswer;
      const result = evaluateChecklist(items, answers, thresholds);

      allowed.checklistVersionId = body.checklistVersionId;
      allowed.setupGrade = result.grade;
      allowed.setupScore = String(result.score);

      // Upsert the evaluation row: if an evaluation already exists for this
      // trade+version, update it in place; otherwise create a new one.
      const existingEval = await db.tradeChecklistEvaluation.findFirst({
        where: { tradeId: id, checklistVersionId: body.checklistVersionId },
      });
      try {
        if (existingEval) {
          await db.tradeChecklistEvaluation.update({
            where: { id: existingEval.id },
            data: {
              rawAnswersJson: serializeAnswers(answers),
              weightedScore: String(result.score),
              finalGrade: result.grade,
              evaluatedAt: new Date(),
            },
          });
        } else {
          await db.tradeChecklistEvaluation.create({
            data: {
              tradeId: id,
              checklistVersionId: body.checklistVersionId,
              rawAnswersJson: serializeAnswers(answers),
              weightedScore: String(result.score),
              finalGrade: result.grade,
            },
          });
        }
      } catch {
        // Non-fatal: trade update proceeds regardless.
        await audit("trade.checklist_eval_failed", "trade", id);
      }
    }
  }

  try {
    const updated = await db.trade.update({
      where: { id },
      data: allowed,
      include: { executions: { orderBy: { seq: "asc" } } },
    });
    await audit("trade.updated", "trade", id);
    return ok(updated);
  } catch (err: any) {
    // Prisma P2003 = foreign key constraint violation
    if (err?.code === "P2003") {
      return bad("Invalid reference: one of the provided IDs (strategy, instrument, etc.) does not exist.");
    }
    return bad("Failed to update trade.");
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  let user;
  try { user = await requireUser(); } catch (e) { return toApiError(e); }
  const { id } = await ctx.params;
  const trade = await db.trade.findFirst({ where: { id, userId: user.id } });
  if (!trade) return notFound("Trade not found");
  await db.trade.delete({ where: { id } });
  await audit("trade.deleted", "trade", id);
  return ok({ ok: true });
}
