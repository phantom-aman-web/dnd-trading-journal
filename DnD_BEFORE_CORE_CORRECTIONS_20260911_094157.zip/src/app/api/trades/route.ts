import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser, forbidden } from "@/lib/auth";
import { ok, bad, toApiError, parseJson } from "@/lib/api";
import { calculateTradePnl, TradeCalcInput, computePointValueCents } from "@/lib/calculations";
import {
  evaluateChecklist,
  parseChecklistItems,
  parseGradingThresholds,
  serializeAnswers,
  type ChecklistAnswer,
} from "@/lib/checklist-evaluation";
import { audit } from "@/lib/audit";

const ExecutionSchema = z.object({
  kind: z.enum(["entry", "exit"]),
  price: z.string(),
  quantity: z.string(),
  timestamp: z.string().datetime().optional(),
  notes: z.string().optional(),
});

const TradeCreateSchema = z.object({
  accountId: z.string(),
  instrumentId: z.string().optional().nullable(),
  instrumentSymbol: z.string(),
  market: z.string().optional().nullable(),
  direction: z.enum(["long", "short"]),
  session: z.string().optional().nullable(),
  newsEvent: z.string().optional().nullable(),
  strategyId: z.string().optional().nullable(),
  strategyVersionId: z.string().optional().nullable(),
  dailyPlanId: z.string().optional().nullable(),
  checklistVersionId: z.string().optional().nullable(),
  checklistAnswers: z.record(z.string(), z.any()).optional().nullable(),
  setupGrade: z.string().optional().nullable(),
  setupScore: z.string().optional().nullable(),
  tags: z.array(z.string()).default([]),
  plannedEntryPrice: z.string().optional().nullable(),
  plannedStopPrice: z.string().optional().nullable(),
  plannedTargetPrice: z.string().optional().nullable(),
  plannedRiskPct: z.string().optional().nullable(),
  executions: z.array(ExecutionSchema).default([]),
  feesCents: z.number().int().default(0),
  commissionCents: z.number().int().default(0),
  swapCents: z.number().int().default(0),
  slippageCents: z.number().int().default(0),
  entryTime: z.string().datetime().optional().nullable(),
  exitTime: z.string().datetime().optional().nullable(),
  tradingTimezone: z.string().default("UTC"),
  setup: z.record(z.string(), z.any()).optional().nullable(),
  thesis: z.record(z.string(), z.any()).optional().nullable(),
  notes: z.string().optional().nullable(),
  lessons: z.string().optional().nullable(),
  planAdherence: z.record(z.string(), z.any()).optional().nullable(),
  psychBefore: z.record(z.string(), z.any()).optional().nullable(),
  psychAfter: z.record(z.string(), z.any()).optional().nullable(),
  ruleCompliance: z.record(z.string(), z.any()).optional().nullable(),
  behaviorFlags: z.array(z.string()).default([]),
  status: z.string().default("open"),
  isDraft: z.boolean().default(false),
});

const ListQuerySchema = z.object({
  limit: z.coerce.number().min(1).max(200).default(100),
  cursor: z.string().optional(),
  search: z.string().optional(),
  accountId: z.string().optional(),
  instrumentId: z.string().optional(),
  strategyId: z.string().optional(),
  session: z.string().optional(),
  status: z.string().optional(),
  direction: z.enum(["long", "short"]).optional(),
  setupGrade: z.string().optional(),
  tag: z.string().optional(),
  fromDate: z.string().optional(),
  toDate: z.string().optional(),
  sortBy: z.string().default("entryTime"),
  sortDir: z.enum(["asc", "desc"]).default("desc"),
  includeArchived: z.coerce.boolean().default(false),
});

export async function GET(req: NextRequest) {
  let user;
  try { user = await requireUser(); } catch (e) { return toApiError(e); }

  const url = new URL(req.url);
  const params = Object.fromEntries(url.searchParams.entries());
  const parsed = ListQuerySchema.safeParse(params);
  if (!parsed.success) return bad("Invalid query", parsed.error.flatten());
  const q = parsed.data;

  // Authorization: enforce userId ownership on every query (spec section 100/101)
  const where: any = { userId: user.id, isArchived: q.includeArchived ? undefined : false };
  if (q.includeArchived === false) where.isArchived = false;
  if (q.accountId) where.accountId = q.accountId;
  if (q.instrumentId) where.instrumentId = q.instrumentId;
  if (q.strategyId) where.strategyId = q.strategyId;
  if (q.session) where.session = q.session;
  if (q.status) where.status = q.status;
  if (q.direction) where.direction = q.direction;
  if (q.setupGrade) where.setupGrade = q.setupGrade;
  if (q.tag) where.tagsJson = { contains: `"${q.tag}"` };
  if (q.search) {
    where.OR = [
      { instrumentSymbol: { contains: q.search } },
      { notes: { contains: q.search } },
    ];
  }
  if (q.fromDate || q.toDate) {
    where.entryTime = {};
    if (q.fromDate) where.entryTime.gte = new Date(q.fromDate);
    if (q.toDate) where.entryTime.lte = new Date(q.toDate);
  }

  const trades = await db.trade.findMany({
    where,
    orderBy: { [q.sortBy]: q.sortDir },
    take: q.limit + 1,
    ...(q.cursor ? { skip: 1, cursor: { id: q.cursor } } : {}),
    include: {
      executions: { orderBy: { seq: "asc" } },
      strategy: { select: { id: true, name: true } },
      strategyVersion: { select: { id: true, versionLabel: true } },
    },
  });

  const hasMore = trades.length > q.limit;
  const items = hasMore ? trades.slice(0, q.limit) : trades;
  return ok({
    items,
    nextCursor: hasMore ? items[items.length - 1].id : null,
    total: items.length,
  });
}

export async function POST(req: NextRequest) {
  let user;
  try { user = await requireUser(); } catch (e) { return toApiError(e); }
  const body = await parseJson(req);
  if (!body) return bad("Invalid JSON body");
  const parsed = TradeCreateSchema.safeParse(body);
  if (!parsed.success) return bad("Invalid input", parsed.error.flatten());
  const data = parsed.data;

  // Normalize the instrument symbol: trim whitespace + uppercase. This
  // guarantees a single canonical form in the database regardless of what
  // the client sends (some legacy clients may still submit lowercase or
  // whitespace-padded symbols). The normalized value is used everywhere
  // `data.instrumentSymbol` was previously referenced below.
  const normalizedSymbol = (data.instrumentSymbol || "").trim().toUpperCase();
  data.instrumentSymbol = normalizedSymbol;

  // Authorization: verify account belongs to user (spec section 101)
  const account = await db.tradingAccount.findFirst({
    where: { id: data.accountId, userId: user.id },
  });
  if (!account) return bad("Account not found or not owned by user");

  if (data.instrumentId) {
    const instr = await db.instrument.findFirst({
      where: { id: data.instrumentId, userId: user.id },
    });
    if (!instr) return bad("Instrument not found or not owned by user");
  }
  if (data.strategyId) {
    const strat = await db.strategy.findFirst({
      where: { id: data.strategyId, userId: user.id },
    });
    if (!strat) return bad("Strategy not found or not owned by user");
  }
  if (data.dailyPlanId) {
    const plan = await db.dailyPlan.findFirst({
      where: { id: data.dailyPlanId, userId: user.id },
    });
    if (!plan) return bad("Daily plan not found or not owned by user");
  }

  // Server-side financial calculation (spec section 31)
  const instrument = data.instrumentId
    ? await db.instrument.findFirst({ where: { id: data.instrumentId, userId: user.id } })
    : null;
  const calcInput: TradeCalcInput = {
    direction: data.direction,
    plannedEntryPrice: data.plannedEntryPrice,
    plannedStopPrice: data.plannedStopPrice,
    plannedTargetPrice: data.plannedTargetPrice,
    fills: data.executions.map((e) => ({
      kind: e.kind,
      price: e.price,
      quantity: e.quantity,
    })),
    feesCents: data.feesCents,
    commissionCents: data.commissionCents,
    swapCents: data.swapCents,
    slippageCents: data.slippageCents,
    contractSize: instrument?.contractSize ?? "1",
    pipSize: instrument?.pipSize ?? "0.0001",
    // Instrument-aware point value (spec §31, §7): derive from the
    // contractSize + tickSize/pipSize rather than the legacy hardcoded 100.
    // Forex standard lot → 1000 cents ($10/pip), metals/indices/futures →
    // contractSize * tickSize * 100, crypto/stocks → 100 (1:1 with price).
    pointValueCents: computePointValueCents(
      instrument?.contractSize ?? "1",
      instrument?.tickSize ?? null,
      instrument?.pipSize ?? null,
    ),
  };
  const calc = calculateTradePnl(calcInput);

  // Authoritative A+ checklist evaluation. The client sends the user's raw
  // answers (`checklistAnswers`) and the `checklistVersionId` they were
  // answering against. We re-fetch the version, re-evaluate, and override
  // `setupGrade`/`setupScore` with the server-computed result so the client
  // can never inject a higher grade than the answers warrant (spec §102).
  let setupGrade = data.setupGrade;
  let setupScore = data.setupScore;
  let pendingEvaluation: {
    checklistVersionId: string;
    rawAnswersJson: string;
    weightedScore: string;
    finalGrade: string;
  } | null = null;

  if (data.checklistVersionId && data.checklistAnswers && typeof data.checklistAnswers === "object") {
    const version = await db.checklistVersion.findFirst({
      where: { id: data.checklistVersionId, checklist: { userId: user.id } },
    });
    if (version) {
      const items = parseChecklistItems(version.itemsJson);
      const thresholds = parseGradingThresholds(version.gradingThresholdsJson);
      const answers = data.checklistAnswers as ChecklistAnswer;
      const result = evaluateChecklist(items, answers, thresholds);
      setupGrade = result.grade;
      setupScore = String(result.score);
      pendingEvaluation = {
        checklistVersionId: version.id,
        rawAnswersJson: serializeAnswers(answers),
        weightedScore: String(result.score),
        finalGrade: result.grade,
      };
    }
  }

  let trade;
  try {
    trade = await db.trade.create({
      data: {
        userId: user.id,
        accountId: data.accountId,
        instrumentId: data.instrumentId ?? null,
        instrumentSymbol: data.instrumentSymbol,
        market: data.market ?? instrument?.market ?? null,
        direction: data.direction,
        status: data.isDraft ? "open" : data.status,
        session: data.session,
        newsEvent: data.newsEvent ?? "none",
        strategyId: data.strategyId,
        strategyVersionId: data.strategyVersionId,
        dailyPlanId: data.dailyPlanId,
        checklistVersionId: data.checklistVersionId,
        setupGrade,
        setupScore,
        tagsJson: JSON.stringify(data.tags),
        plannedEntryPrice: data.plannedEntryPrice,
        plannedStopPrice: data.plannedStopPrice,
        plannedTargetPrice: data.plannedTargetPrice,
        plannedRiskPct: data.plannedRiskPct,
        entryPriceAvg: calc.entryPriceAvg,
        exitPriceAvg: calc.exitPriceAvg,
        positionSize: data.executions.find((e) => e.kind === "entry")?.quantity ?? null,
        feesCents: data.feesCents,
        commissionCents: data.commissionCents,
        swapCents: data.swapCents,
        slippageCents: data.slippageCents,
        grossPnlCents: calc.grossPnlCents,
        netPnlCents: calc.netPnlCents,
        actualR: calc.actualR,
        entryTime: data.entryTime ?? (data.executions.find((e) => e.kind === "entry")?.timestamp ?? null),
        exitTime: data.exitTime ?? (data.executions.find((e) => e.kind === "exit")?.timestamp ?? null),
        tradingTimezone: data.tradingTimezone,
        setupJson: data.setup ? JSON.stringify(data.setup) : null,
        thesisJson: data.thesis ? JSON.stringify(data.thesis) : null,
        notes: data.notes,
        lessons: data.lessons,
        planAdherenceJson: data.planAdherence ? JSON.stringify(data.planAdherence) : (data.ruleCompliance ? JSON.stringify({ ruleCompliance: data.ruleCompliance }) : null),
        psychBeforeJson: data.psychBefore ? JSON.stringify(data.psychBefore) : null,
        psychAfterJson: data.psychAfter ? JSON.stringify(data.psychAfter) : null,
        behaviorFlagsJson: JSON.stringify(data.behaviorFlags),
        isDraft: data.isDraft,
        executions: {
          create: data.executions.map((e, idx) => ({
            kind: e.kind,
            seq: idx,
            price: e.price,
            quantity: e.quantity,
            timestamp: e.timestamp ? new Date(e.timestamp) : new Date(),
            notes: e.notes,
          })),
        },
      },
      include: { executions: true },
    });
  } catch (err: any) {
    if (err?.code === "P2003") {
      return bad("Invalid reference: one of the provided IDs (strategy, instrument, etc.) does not exist.");
    }
    return bad("Failed to create trade.");
  }

  await audit("trade.created", "trade", trade.id, { symbol: trade.instrumentSymbol });

  // Persist the TradeChecklistEvaluation row (spec section 41) — the snapshot
  // of the user's answers + the computed score/grade at trade-creation time.
  if (pendingEvaluation) {
    try {
      await db.tradeChecklistEvaluation.create({
        data: {
          tradeId: trade.id,
          checklistVersionId: pendingEvaluation.checklistVersionId,
          rawAnswersJson: pendingEvaluation.rawAnswersJson,
          weightedScore: pendingEvaluation.weightedScore,
          finalGrade: pendingEvaluation.finalGrade,
        },
      });
    } catch {
      // Non-fatal: the trade itself was created. Log via audit and continue.
      await audit("trade.checklist_eval_failed", "trade", trade.id);
    }
  }

  return ok(trade);
}
