/**
 * DnD — Auth utilities.
 * Credentials-based email/password with bcrypt, signed httpOnly JWT session cookie.
 * Per spec section 18: do not hand-roll password storage; we use bcrypt for hashing.
 */

import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "./db";

const SESSION_COOKIE = "dnd_session";
const SESSION_DEFAULT_SECRET = "dnd-dev-secret-change-in-production-32+chars";
const SESSION_SECRET = process.env.SESSION_SECRET || SESSION_DEFAULT_SECRET;
const SESSION_MAX_AGE = 60 * 60 * 24 * 30; // 30 days

// Warn loudly if the session secret is still the insecure default in any
// non-test environment. We deliberately do NOT throw — the dev environment
// has historically relied on this fallback, and hard-failing here would
// brick local development and the auto dev server. The console.error is
// surfaced once at module load so operators see it in the dev log.
if (
  SESSION_SECRET === SESSION_DEFAULT_SECRET &&
  process.env.NODE_ENV !== "test" &&
  typeof console !== "undefined" &&
  console.error
) {
  console.error(
    "[security] SESSION_SECRET is using its insecure default value. " +
      "Set the SESSION_SECRET environment variable to a string of at least 32 random characters " +
      "before deploying to production. See .env.example.",
  );
}
const encoder = new TextEncoder();

function getKey() {
  return encoder.encode(SESSION_SECRET);
}

export interface SessionPayload {
  sub: string; // user id
  email: string;
  iat?: number;
  exp?: number;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createSessionToken(payload: { sub: string; email: string }): Promise<string> {
  return new SignJWT({ email: payload.email })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_MAX_AGE}s`)
    .sign(getKey());
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getKey());
    if (!payload.sub || typeof payload.email !== "string") return null;
    return { sub: payload.sub, email: payload.email };
  } catch {
    return null;
  }
}

export async function getSessionUser() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = await verifySessionToken(token);
  if (!payload) return null;
  const user = await db.user.findUnique({
    where: { id: payload.sub },
    select: {
      id: true,
      email: true,
      name: true,
      createdAt: true,
      settings: { select: { timezone: true } },
    },
  });
  // Flatten the user's timezone (from UserSettings, default "UTC") onto the
  // returned session user so callers (calendar/analytics/etc.) can do
  // timezone-aware date math without an extra DB round-trip.
  return user
    ? { ...user, timezone: user.settings?.timezone ?? "UTC" }
    : null;
}

export async function setSessionCookie(token: string) {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
}

export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE;

/**
 * Authorize a user-owned resource. Throws 403-shaped error if missing or owned by another user.
 * Per spec section 101: every protected operation must perform authorization.
 */
export async function requireUser() {
  const user = await getSessionUser();
  if (!user) {
    const err = new Error("Unauthorized");
    (err as any).statusCode = 401;
    throw err;
  }
  return user;
}

export function notFound(msg = "Not found") {
  const err = new Error(msg);
  (err as any).statusCode = 404;
  throw err;
}

export function forbidden(msg = "Forbidden") {
  const err = new Error(msg);
  (err as any).statusCode = 403;
  throw err;
}
