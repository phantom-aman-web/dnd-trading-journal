/**
 * DnD — Storage helpers.
 * Per spec section 49: private object storage with short-lived signed URLs.
 * This implementation uses the local filesystem under /home/z/my-project/storage/
 * and serves files via a signed-token API endpoint.
 */

import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

export const STORAGE_ROOT = "/home/z/my-project/storage";

const SIGNED_URL_DEFAULT_SECRET = "dnd-storage-secret-change-in-prod";
const SIGNED_URL_SECRET = process.env.STORAGE_SECRET || SIGNED_URL_DEFAULT_SECRET;
const SIGNED_URL_TTL = 60 * 15; // 15 minutes

// Warn loudly if the storage secret is still the insecure default. As with
// SESSION_SECRET in auth.ts we do NOT throw — the dev environment depends on
// the fallback, and throwing here would break local development and the
// auto dev server. The console.error is surfaced once at module load.
if (
  SIGNED_URL_SECRET === SIGNED_URL_DEFAULT_SECRET &&
  process.env.NODE_ENV !== "test" &&
  typeof console !== "undefined" &&
  console.error
) {
  console.error(
    "[security] STORAGE_SECRET is using its insecure default value. " +
      "Set the STORAGE_SECRET environment variable to a string of at least 32 random characters " +
      "before deploying to production. See .env.example.",
  );
}

export async function ensureStorage(): Promise<void> {
  await fs.mkdir(STORAGE_ROOT, { recursive: true });
}

/**
 * Save an uploaded file (Buffer) and return its stored relative path.
 * Files are namespaced by userId to enforce ownership.
 */
export async function saveUpload(
  userId: string,
  filename: string,
  data: Buffer,
  subdir = "media",
): Promise<string> {
  await ensureStorage();
  const safeName = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  const id = crypto.randomUUID();
  const dir = path.join(STORAGE_ROOT, userId, subdir);
  await fs.mkdir(dir, { recursive: true });
  const stored = `${id}-${safeName}`;
  await fs.writeFile(path.join(dir, stored), data);
  return `${userId}/${subdir}/${stored}`;
}

/** Resolve a stored relative path to an absolute filesystem path. */
export function resolveStoredPath(stored: string): string {
  // prevent path traversal
  const safe = stored.replace(/\.\./g, "").replace(/^\/+/, "");
  return path.join(STORAGE_ROOT, safe);
}

/** Read a stored file as Buffer. */
export async function readStored(stored: string): Promise<Buffer> {
  return fs.readFile(resolveStoredPath(stored));
}

/** Get file size in bytes. */
export async function storedSize(stored: string): Promise<number> {
  const stat = await fs.stat(resolveStoredPath(stored));
  return stat.size;
}

/** Delete a stored file (best-effort). */
export async function deleteStored(stored: string): Promise<void> {
  try {
    await fs.unlink(resolveStoredPath(stored));
  } catch {
    /* ignore */
  }
}

/**
 * Generate a short-lived signed token for a stored file.
 * Token = base64url(payload).signature, payload = { p: stored, exp: ts }
 */
export function signFileToken(stored: string): string {
  const payload = {
    p: stored,
    exp: Math.floor(Date.now() / 1000) + SIGNED_URL_TTL,
  };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", SIGNED_URL_SECRET).update(body).digest("base64url");
  return `${body}.${sig}`;
}

export interface SignedTokenPayload {
  p: string;
  exp: number;
}

export function verifyFileToken(token: string): SignedTokenPayload | null {
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = crypto.createHmac("sha256", SIGNED_URL_SECRET).update(body).digest("base64url");
  // Constant-time comparison to prevent timing-attack oracle on token
  // forgery (spec section 49). `crypto.timingSafeEqual` throws when the two
  // buffers differ in length, which itself would be a distinguishable
  // failure mode — guard with a length pre-check that returns early without
  // short-circuiting on a single-character mismatch.
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length) return null;
  if (!crypto.timingSafeEqual(sigBuf, expBuf)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as SignedTokenPayload;
    if (typeof payload.exp !== "number" || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

/** Build a relative signed URL for use in the frontend. */
export function buildSignedUrl(stored: string): string {
  return `/api/media/file?token=${signFileToken(stored)}`;
}

/** MIME types allowed for images and videos (spec section 104). */
export const ALLOWED_IMAGE_MIMES = ["image/png", "image/jpeg", "image/webp", "image/gif"];
export const ALLOWED_VIDEO_MIMES = ["video/mp4", "video/webm", "video/quicktime"];

export function isAllowedImageMime(mime: string): boolean {
  return ALLOWED_IMAGE_MIMES.includes(mime.toLowerCase());
}
export function isAllowedVideoMime(mime: string): boolean {
  return ALLOWED_VIDEO_MIMES.includes(mime.toLowerCase());
}

export const MAX_IMAGE_BYTES = 20 * 1024 * 1024; // 20 MB
export const MAX_VIDEO_BYTES = 500 * 1024 * 1024; // 500 MB
