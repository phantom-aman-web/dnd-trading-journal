"use client";

import { useEffect, useState, useCallback } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export type NyMarketOffset = "UTC-4" | "UTC-5";

interface MarketClockProps {
  offset: NyMarketOffset;
  onOffsetChange: (offset: NyMarketOffset) => void;
}

const SESSIONS = [
  { value: "asian_range", label: "Asian", short: "Asian" },
  { value: "london_open", label: "London", short: "London" },
  { value: "ny_am", label: "NY AM", short: "NY AM" },
  { value: "ny_lunch", label: "NY Lunch", short: "NY Lunch" },
  { value: "ny_pm", label: "NY PM", short: "NY PM" },
  { value: "off_hours", label: "Off Hours", short: "Off" },
] as const;

/**
 * Determine the current trading session based on New York market hour.
 * Uses the actual America/New_York timezone (DST-aware via Intl), then
 * applies the user's display offset preference for the label.
 *
 * Session boundaries (in NY local time):
 *   Asian Range:  20:00 – 03:00
 *   London Open:  03:00 – 08:30
 *   NY AM:        08:30 – 12:00
 *   NY Lunch:     12:00 – 13:00
 *   NY PM:        13:00 – 17:00
 *   Off Hours:    17:00 – 20:00
 */
function getSessionForNyHour(hour: number, minute: number): string {
  const time = hour + minute / 60;
  if (time >= 20 || time < 3) return "asian_range";
  if (time >= 3 && time < 8.5) return "london_open";
  if (time >= 8.5 && time < 12) return "ny_am";
  if (time >= 12 && time < 13) return "ny_lunch";
  if (time >= 13 && time < 17) return "ny_pm";
  return "off_hours";
}

function getSessionLabel(sessionValue: string): string {
  return SESSIONS.find((s) => s.value === sessionValue)?.short ?? "—";
}

export function MarketClock({ offset, onOffsetChange }: MarketClockProps) {
  const [now, setNow] = useState<Date>(new Date());

  // Update every second
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Get New York time using Intl (DST-aware)
  // We use America/New_York which automatically handles EDT (UTC-4) and EST (UTC-5)
  const nyTime = useCallback((date: Date) => {
    const formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/New_York",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
    const parts = formatter.formatToParts(date);
    const hour = parts.find((p) => p.type === "hour")?.value ?? "0";
    const minute = parts.find((p) => p.type === "minute")?.value ?? "0";
    const second = parts.find((p) => p.type === "second")?.value ?? "0";
    const dayPeriod = parts.find((p) => p.type === "dayPeriod")?.value ?? "AM";

    // Get the numeric hour for session calculation
    let hourNum = parseInt(hour, 10);
    if (dayPeriod === "PM" && hourNum !== 12) hourNum += 12;
    if (dayPeriod === "AM" && hourNum === 12) hourNum = 0;
    const minuteNum = parseInt(minute, 10);

    const session = getSessionForNyHour(hourNum, minuteNum);

    return {
      time: `${hour}:${minute}:${second} ${dayPeriod}`,
      session,
      sessionLabel: getSessionLabel(session),
    };
  }, []);

  const { time, sessionLabel } = nyTime(now);

  // Mobile compact format (no seconds)
  const timeMobile = useCallback((date: Date) => {
    const formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/New_York",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
    return formatter.format(date);
  }, []);

  const shortTime = timeMobile(now);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className="inline-flex items-center gap-1.5 h-9 px-2.5 rounded-md hover:bg-muted transition-colors"
          aria-label="New York market clock"
        >
          <Clock className="h-3.5 w-3.5 text-muted-foreground" />
          <div className="flex flex-col items-start leading-none">
            <span className="text-[11px] font-mono font-medium tabular-nums text-foreground hidden sm:inline">
              {time}
            </span>
            <span className="text-[11px] font-mono font-medium tabular-nums text-foreground sm:hidden">
              {shortTime}
            </span>
            <span className="text-[9px] text-muted-foreground mt-0.5">
              <span className="hidden sm:inline">{offset} · </span>
              {sessionLabel}
            </span>
          </div>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs">New York Market Time</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <div className="px-2 py-1.5">
          <div className="text-sm font-mono font-medium tabular-nums">
            {time}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {offset} · {sessionLabel}
          </div>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuLabel className="text-xs">Display Offset</DropdownMenuLabel>
        <DropdownMenuItem
          onClick={() => onOffsetChange("UTC-4")}
          className={cn("flex items-center gap-2", offset === "UTC-4" && "font-semibold")}
        >
          <span className={cn(
            "h-2 w-2 rounded-full",
            offset === "UTC-4" ? "bg-primary" : "bg-transparent border border-border"
          )} />
          UTC-4 (EDT)
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => onOffsetChange("UTC-5")}
          className={cn("flex items-center gap-2", offset === "UTC-5" && "font-semibold")}
        >
          <span className={cn(
            "h-2 w-2 rounded-full",
            offset === "UTC-5" ? "bg-primary" : "bg-transparent border border-border"
          )} />
          UTC-5 (EST)
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
